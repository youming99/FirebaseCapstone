package halla.icsw.firebasecapstone;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    TextView authenticationTextview, gameTextview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.signUpTextView).setOnClickListener(onClickListener); // 회원가입
        findViewById(R.id.logInTextView).setOnClickListener(onClickListener); // 로그인
        findViewById(R.id.logOutTextView).setOnClickListener(onClickListener); // 로그아웃
        findViewById(R.id.gameTextview).setOnClickListener(onClickListener); // 게임하기
        findViewById(R.id.realtimeDBTextView).setOnClickListener(onClickListener);


    }

    // 눌렀을 때
    View.OnClickListener onClickListener = new View.OnClickListener(){
        @Override
        public void onClick(View v){
            switch (v.getId()){
                case R.id.signUpTextView :
                    Intent intent = new Intent(MainActivity.this, SignUpActivity.class);
                    startActivity(intent);
                    break;
                case R.id.logInTextView :
                    Intent intent2 = new Intent(MainActivity.this, LogInActivity.class);
                    startActivity(intent2);
                    break;
                case R.id.logOutTextView :
                    logoutDialog();
                    break;
                case R.id.gameTextview :
                    Intent intent3 = new Intent(MainActivity.this, GameActivity.class);
                    startActivity(intent3);
                    break;
                case R.id.realtimeDBTextView:
                    Intent intent4= new Intent(MainActivity.this, RealtimeDBActivity.class);
                    startActivity(intent4);
                    break;
            }
        }
    };

    //로그아웃 다이얼로그
    void logoutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("로그아웃 하시겠습니까?");
        builder
                .setMessage("예/아니오 선택하시오.")
                .setCancelable(false)
                .setPositiveButton("예",
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dialog, int id) {
                                // 프로그램을 종료한다
                                FirebaseAuth.getInstance().signOut();
                            }
                        })
                .setNegativeButton("아니오",
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dialog, int id) {
                                // 다이얼로그를 취소한다
                                dialog.cancel();
                            }
                        });
        AlertDialog alertDialog = builder.show();
        alertDialog.show();
    }

}
