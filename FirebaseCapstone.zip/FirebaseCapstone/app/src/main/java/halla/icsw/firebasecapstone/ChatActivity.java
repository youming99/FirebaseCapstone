package halla.icsw.firebasecapstone;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ChatActivity extends AppCompatActivity {

    private String CHAT_NAME;
    private String USER_NAME;

    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference databaseReference = firebaseDatabase.getReference();

    TextView msg;
    TextView student1Text, student2Text, professorText, timerText;
    EditText student1EditText, student2EditText, professorEditText;
    Button student1Button, student2Button, professorButton, startButton;


    //메시지 선언
    String startMsg = "교수는 1~100 사이의 수를 고르세요.";
    String professorMsg = "교수님이 숫자를 입력하였습니다.\n큰수/작은수를 선택하여주세요.";
    String professorMsg2 = "교수님이 큰수/작은수 선택하였습니다.\n학생 1은 숫자를 입력하세요.";
    String student1Msg = "학생 1이 숫자를 입력하였습니다.\n학생 2가 숫자를 입력하세요.";
    String student1WinMsg = "학생 1이 이겼습니다.";
    String student2WinMsg = "학생 2가 이겼습니다.";
    String professorWinMsg = "교수가 이겼습니다.";
    String s_p_winMsg = "모두가 무승부입니다.";
    String s_WinMsg = "학생 1, 학생 2 가 무승부입니다.";
    String big_small = "";
    String startCheckMsg = "3명이 다 들어왔습니다.";

    int student1Str = 0;
    int student2Str = 0;
    int professorStr = 0;

    String check="";
    String in;
    Boolean c=true;


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        msg = findViewById(R.id.text); // 문제 출제 텍스트
        student1Text = findViewById(R.id.student1Text); // 학생1 텍스트
        student2Text = findViewById(R.id.student2Text); // 학생2 텍스트
        professorText = findViewById(R.id.professorText); // 교수 텍스트
        student1EditText = findViewById(R.id.student1EditText); // 학생1 입력 테스트
        student2EditText = findViewById(R.id.student2EditText); // 학생2 입력 테스트
        professorEditText = findViewById(R.id.proffesorEditText); // 교수 입력 테스트
        //timerText = findViewById(R.id.timertext);

        student1Button = findViewById(R.id.student1Button); // 학생 1 버튼
        student2Button = findViewById(R.id.student2Button); // 학생 2 버튼
        professorButton = findViewById(R.id.professorButton); // 교수 버튼
        startButton = findViewById(R.id.startButton); // 다음 게임 버튼

        //focus 없애기
        student1EditText.clearFocus();
        student2EditText.clearFocus();
        professorEditText.clearFocus();

        // GameActivity에서 받아온 Intent
        Intent intent = getIntent();
        CHAT_NAME = intent.getStringExtra("chatName");
        USER_NAME = intent.getStringExtra("userName");

        // 참여자가 교수일 경우
        if(USER_NAME.equals("교수")){
            databaseReference.child("game").child(CHAT_NAME).child("msg").child("checkMSG").setValue("교수");
            databaseReference.child("game").child(CHAT_NAME).child("msg").child("checkMSG").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    check = snapshot.getValue(String.class);
                    in="교수";
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
            professorEditTextListener();
            switchFunction();
            professorText.setTextColor(Color.BLUE);
            student1EditText.setInputType(InputType.TYPE_NULL);
            student2EditText.setInputType(InputType.TYPE_NULL);

         // 참여자가 학생 1일 경우
        }else if(USER_NAME.equals("학생1")){

            databaseReference.child("game").child(CHAT_NAME).child("msg").child("checkMSG").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    check = snapshot.getValue(String.class);
                    check+=" 학생1";
                    while(c) {
                        databaseReference.child("game").child(CHAT_NAME).child("msg").child("checkMSG").setValue(check);
                        c=false;
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
            student1Text.setTextColor(Color.BLUE);
            student1EditTextListener();
            student2EditText.setInputType(InputType.TYPE_NULL);
            professorEditText.setInputType(InputType.TYPE_NULL);
            startButton.setVisibility(View.GONE);
        }

        //참여자가 학생 2일 경우
        else if(USER_NAME.equals("학생2")){
            databaseReference.child("game").child(CHAT_NAME).child("msg").child("checkMSG").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    check = snapshot.getValue(String.class);
                    check+=" 학생2";
                    while(c) {
                        databaseReference.child("game").child(CHAT_NAME).child("msg").child("checkMSG").setValue(check);
                        c=false;
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
            student2Text.setTextColor(Color.BLUE);
            student1EditText.setInputType(InputType.TYPE_NULL);
            professorEditText.setInputType(InputType.TYPE_NULL);
            startButton.setVisibility(View.GONE);
            student2EditTextListener();
        }

        //시작
        databaseReference.child("game").child(CHAT_NAME).child("msg").child("checkMSG").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String text = snapshot.getValue(String.class);

                if(text.equals("교수 학생1 학생2") || text.equals("교수 학생2 학생1")){
                    msg.setText(startCheckMsg + "\n" + startMsg);
                    openChat();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        // 다음게임 버튼 클릭 시
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //학생들과 교수의 입력 텍스트는 다 지움
                student1EditText.setText("");
                student2EditText.setText("");
                professorEditText.setText("");

                //학생들과 교수의 모든 데이터를 없앰
                databaseReference.child("game").child(CHAT_NAME).child("number").child("교수").setValue("");
                databaseReference.child("game").child(CHAT_NAME).child("number").child("학생1").setValue("");
                databaseReference.child("game").child(CHAT_NAME).child("number").child("학생2").setValue("");
                databaseReference.child("game").child(CHAT_NAME).child("number").child("비교").setValue("");
                databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").setValue(startMsg);
                professorEditText.setText("");
                student1EditText.setText("");
                student2EditText.setText("");

                openChat();
            }
        });

    }

    // 키보드 자판 숨김
    private void hidekeyboard(EditText et){
        InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(et.getWindowToken(),0);
    }

    //본격 게임 시작 함수
    private void openChat(){
        databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").setValue(startMsg);
        databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String text = snapshot.getValue(String.class);
                msg.setText(text);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        professorEditTextListener();
    }

    // 참여자가 교수일 경우
    private void professorEditTextListener() {
        // 교수 숫자저장 버튼을 누를 경우
        professorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 어떤 숫자라도 입력했을 경우에만 데이터에 저장
                if(!professorEditText.getText().equals("")){
                    String p3=professorEditText.getText().toString();
                    databaseReference.child("game").child(CHAT_NAME).child("number").child("교수").setValue(p3);
                    databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").setValue(professorMsg);
                    databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            String text = snapshot.getValue(String.class);
                            // msg.setText(text);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                    hidekeyboard(professorEditText);
                }
            }
        });
    }

    //참여자가 학생1일 경우
    private void student1EditTextListener(){
        //학생 1 숫자저장 버튼을 누를 경우
        student1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!student1EditText.getText().equals("")){
                    String s1=student1EditText.getText().toString();
                    databaseReference.child("game").child(CHAT_NAME).child("number").child("학생1").setValue(s1);
                    databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").setValue(student1Msg);
                    databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            String text = snapshot.getValue(String.class);
                            //  msg.setText(text);

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }
        });
    }

    //참여자가 학생2일 경우
    private void student2EditTextListener(){
        //학생 2 숫자 저장 버튼을 누를 경우
        student2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!student2EditText.getText().equals("")){
                    String s2=student2EditText.getText().toString();
                    databaseReference.child("game").child(CHAT_NAME).child("number").child("학생2").setValue(s2);
                    hidekeyboard(student2EditText);
                    comparison();
                }
            }
        });
    }

    // 참여자가 교수일 경우 큰수/작은수 선택하는 함수
    private void switchFunction() {
        Switch switchButton = findViewById(R.id.switch1);
        switchButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                // check가 된 경우 작은 수
                if (isChecked){
                    Toast.makeText(ChatActivity.this, "작은 수", Toast.LENGTH_SHORT).show();
                    databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").setValue(professorMsg2);
                    databaseReference.child("game").child(CHAT_NAME).child("number").child("비교").setValue("작은 수");
                   // check가 안 된 경우 큰 수
                }else{
                    Toast.makeText(ChatActivity.this, "큰 수", Toast.LENGTH_SHORT).show();
                    databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").setValue(professorMsg2);
                    databaseReference.child("game").child(CHAT_NAME).child("number").child("비교").setValue("큰 수");
                }

            }
        });

    }

    // 참여자 3명이서 수를 비교함
    private void comparison(){

        //큰 수 / 작은 수 일 때, 조건문
        databaseReference.child("game").child(CHAT_NAME).child("number").child("비교").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                big_small = snapshot.getValue(String.class);

                //큰수 선택했을 때
                if(big_small.equals("큰 수")){

                    //학생 1
                    databaseReference.child("game").child(CHAT_NAME).child("number").child("학생1").addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            student1Str = Integer.parseInt(snapshot.getValue(String.class));

                            //학생 2
                            databaseReference.child("game").child(CHAT_NAME).child("number").child("학생2").addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    student2Str = Integer.parseInt(snapshot.getValue(String.class));

                                    //교수
                                    databaseReference.child("game").child(CHAT_NAME).child("number").child("교수").addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                            professorStr = Integer.parseInt(snapshot.getValue(String.class));

                                            //비교
                                            //학생 1, 학생 2가 무승부
                                            if(student1Str > professorStr && student2Str > professorStr) {
                                                databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").setValue(s_WinMsg);
                                            }
                                            //학생 1 승리
                                            else if(student1Str > professorStr && student2Str < professorStr){
                                                databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").setValue(student1WinMsg);
                                            }
                                            //학생 2 승리
                                            else if(student1Str < professorStr && student2Str > professorStr){
                                                databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").setValue(student2WinMsg);
                                            }
                                            //학생 1, 학생 2, 교수 무승부
                                            else if(student1Str == student2Str && student1Str == professorStr){
                                                databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").setValue(s_p_winMsg);
                                            }
                                            //교수 승리
                                            else{
                                                databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").setValue(professorWinMsg);
                                            }

                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    });
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                 // 작은 수를 선택했을 때
                }else if (big_small.equals("작은 수")){
                    //학생 1
                    databaseReference.child("game").child(CHAT_NAME).child("number").child("학생1").addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            student1Str = Integer.parseInt(snapshot.getValue(String.class));

                            //학생 2
                            databaseReference.child("game").child(CHAT_NAME).child("number").child("학생2").addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    student2Str = Integer.parseInt(snapshot.getValue(String.class));

                                    //교수
                                    databaseReference.child("game").child(CHAT_NAME).child("number").child("교수").addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                            professorStr = Integer.parseInt(snapshot.getValue(String.class));

                                            //비교
                                            //학생 1, 학생 2가 무승부
                                            if(student1Str < professorStr && student2Str < professorStr) {
                                                databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").setValue(s_WinMsg);
                                            }
                                            //학생 1 승리
                                            else if(student1Str < professorStr && student2Str > professorStr){
                                                databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").setValue(student1WinMsg);
                                            }
                                            //학생 2 승리
                                            else if(student1Str > professorStr && student2Str < professorStr){
                                                databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").setValue(student2WinMsg);
                                            }
                                            //학생 1, 학생 2, 교수 무승부
                                            else if(student1Str == student2Str && student1Str == professorStr){
                                                databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").setValue(s_p_winMsg);
                                            }
                                            //교수 승리
                                            else{
                                                databaseReference.child("game").child(CHAT_NAME).child("msg").child("professorMSG").setValue(professorWinMsg);
                                            }


                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    });
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }


    // 3명이 수를 비교한 후에, 각각의 텍스트에 본인들이 저장했던 숫자를 출력하기 위한 코드이지만 실행이 안됨.(어려움)
    private void answerCheck(){

        //교수 정답 출력
        databaseReference.child("game").child(CHAT_NAME).child("number").child("교수").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String answer = snapshot.getValue(String.class);
                professorEditText.setTextColor(Color.RED);
                professorEditText.setText(answer);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        //학생 1 정답 출력
        databaseReference.child("game").child(CHAT_NAME).child("number").child("학생1").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String answer = snapshot.getValue(String.class);
                student1EditText.setTextColor(Color.RED);
                student1EditText.setText(answer);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        //학생 2 정답 출력
        databaseReference.child("game").child(CHAT_NAME).child("number").child("학생2").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String answer = snapshot.getValue(String.class);
                student2EditText.setTextColor(Color.RED);
                student2EditText.setText(answer);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }



}