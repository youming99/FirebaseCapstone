package halla.icsw.firebasecapstone;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class GameActivity extends AppCompatActivity {

    private EditText user_chat; // 채팅방 이름
    private Button user_next; // 게임하기 버튼
    private ListView chat_list; // 생성된 채팅방 리스트

    RadioGroup radioGroup; // 라디오그룹 선언

    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance(); //fireDatabase 선언
    private DatabaseReference databaseReference = firebaseDatabase.getReference(); // DatabaseReference 선언

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        user_chat = (EditText) findViewById(R.id.user_chat); // 채팅방 이름
        user_next = (Button) findViewById(R.id.user_next); // 게임하기 버튼
        chat_list = (ListView) findViewById(R.id.chat_list); // 채팅방 리스트
        radioGroup = (RadioGroup) findViewById(R.id.radioGroup); // 라디오 그룹


        // 라디오 버튼 눌렀을 시, Toast 메시지 띄움
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i == R.id.proffesorRadioButton){
                    Toast.makeText(GameActivity.this, "교수 선택", Toast.LENGTH_SHORT).show();
                }else if(i==R.id.student1RadioButton){
                    Toast.makeText(GameActivity.this, "학생1 선택", Toast.LENGTH_SHORT).show();
                }else if(i==R.id.student2RadioButton){
                    Toast.makeText(GameActivity.this, "학생2 선택", Toast.LENGTH_SHORT).show();
                }

            }
        });

        // 게임하기 눌렀을 시, Intent로 채팅방 이름과 사용자 이름을 넘겨줌.
        user_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id = radioGroup.getCheckedRadioButtonId();
                RadioButton radioButton = findViewById(id);

                if (user_chat.getText().toString().equals(""))
                    return;
                Intent intent = new Intent(GameActivity.this, ChatActivity.class);
                intent.putExtra("chatName", user_chat.getText().toString());
                intent.putExtra("userName", radioButton.getText().toString());
                startActivity(intent);
            }
        });

        showChatList();

    }

    // 채팅방 리스트 함수
    private void showChatList() {
        // 리스트 어댑터 생성 및 세팅
        final ArrayAdapter<String> adapter
                = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, android.R.id.text1);
        chat_list.setAdapter(adapter);

        // 데이터 받아오기 및 어댑터 데이터 추가 및 삭제 등..리스너 관리
        databaseReference.child("game").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                Log.e("LOG", "dataSnapshot.getKey() : " + dataSnapshot.getKey());
                adapter.add(dataSnapshot.getKey());
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }
}
